<?= view('layouts/header_admin') ?>

<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-icon">👥</div>
        <div class="stat-content">
            <h3>Total Usuarios</h3>
            <div class="stat-value"><?= esc($stats['total_users']) ?></div>
            <?php if (!empty($stats['last_user'])): ?>
                <small>Último: <?= esc($stats['last_user']['name']) ?></small>
            <?php endif; ?>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">📅</div>
        <div class="stat-content">
            <h3>Nuevos Hoy</h3>
            <div class="stat-value"><?= esc($stats['users_today']) ?></div>
            <small>Registrados hoy</small>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">📊</div>
        <div class="stat-content">
            <h3>Esta Semana</h3>
            <div class="stat-value"><?= esc($stats['users_this_week']) ?></div>
            <small>Últimos 7 días</small>
        </div>
    </div>

    <div class="stat-card disabled">
        <div class="stat-icon">💾</div>
        <div class="stat-content">
            <h3>Última Actualización</h3>
            <div class="stat-value"><?= esc($stats['last_data_update']) ?></div>
            <small>Hito 3</small>
        </div>
    </div>
</div>

<div class="dashboard-content">
    <div class="welcome-box">
        <h2>Bienvenido, <?= esc($user_name) ?></h2>
        <p>Estás en el panel administrativo del Dashboard Ambiental Bosque Modelo Palencia.</p>

        <div class="info-panel">
            <h3>Hitos Completados</h3>
            <ul class="checklist">
                <li class="completed">✓ <strong>Hito 1:</strong> Infraestructura base + Autenticación</li>
                <li class="completed">✓ <strong>Hito 2:</strong> CRUD completo de usuarios
                    <ul style="margin-left: 1.5rem; margin-top: 0.5rem;">
                        <li class="completed">✓ Paginación y búsqueda</li>
                        <li class="completed">✓ Validaciones avanzadas</li>
                        <li class="completed">✓ Rate limiting en login</li>
                        <li class="completed">✓ Validación en tiempo real</li>
                        <li class="completed">✓ Estadísticas de usuarios</li>
                    </ul>
                </li>
            </ul>

            <h3>Próximos Hitos</h3>
            <ul class="roadmap">
                <li><strong>Hito 3:</strong> Sistema ETL + Base de datos SQLite</li>
                <li><strong>Hito 4:</strong> API REST + Constructor de componentes</li>
                <li><strong>Hito 5:</strong> Renderizado de componentes visuales</li>
                <li><strong>Hito 6:</strong> Gestión de dashboards dinámicos</li>
                <li><strong>Hito 7:</strong> Mapas + Integración CKAN</li>
            </ul>
        </div>

        <div class="quick-actions">
            <h3>Acciones Rápidas</h3>
            <a href="<?= base_url('/admin-panel-bmp/users') ?>" class="btn btn-primary">
                Gestionar Usuarios
            </a>
            <a href="<?= base_url('/') ?>" class="btn btn-secondary" target="_blank">
                Ver Landing Pública
            </a>
        </div>
    </div>
</div>

<?= view('layouts/footer_admin') ?>
