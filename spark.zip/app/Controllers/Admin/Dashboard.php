<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;

/**
 * Admin Dashboard Controller
 * Panel administrativo principal
 */
class Dashboard extends BaseController
{
    /**
     * Dashboard principal del panel admin
     */
    public function index()
    {
        $userModel = new UserModel();
        $userStats = $userModel->getStatistics();

        $data = [
            'title' => 'Panel Administrativo - Bosque Modelo Palencia',
            'user_name' => session()->get('user_name'),
            'user_email' => session()->get('user_email'),
            'stats' => [
                'total_users' => $userStats['total'],
                'users_today' => $userStats['created_today'],
                'users_this_week' => $userStats['created_this_week'],
                'last_user' => $userStats['last_user'],
                'total_components' => 0, // Placeholder para Hito 4
                'total_dashboards' => 0, // Placeholder para Hito 6
                'last_data_update' => 'N/A' // Placeholder para Hito 3
            ]
        ];

        return view('admin/dashboard', $data);
    }
}
