<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Landing Page Pública
$routes->get('/', 'PublicController::index');
$routes->get('/dashboard', 'PublicController::dashboard');
$routes->get('/dashboard/(:segment)', 'PublicController::dashboard/$1');

// Autenticación (Login)
$routes->get('/admin-panel-bmp/login', 'Auth::login');
$routes->post('/admin-panel-bmp/authenticate', 'Auth::authenticate');
$routes->get('/admin-panel-bmp/logout', 'Auth::logout');

// Panel Administrativo (protegido con AuthFilter)
$routes->group('admin-panel-bmp', ['filter' => 'auth'], function($routes) {
    // Dashboard principal
    $routes->get('/', 'Admin\Dashboard::index');
    $routes->get('dashboard', 'Admin\Dashboard::index');

    // Gestión de usuarios
    $routes->get('users', 'Admin\Users::index');
    $routes->get('users/create', 'Admin\Users::create');
    $routes->post('users/store', 'Admin\Users::store');
    $routes->get('users/edit/(:num)', 'Admin\Users::edit/$1');
    $routes->post('users/update/(:num)', 'Admin\Users::update/$1');
    $routes->post('users/delete/(:num)', 'Admin\Users::delete/$1');

    // Gestión de componentes (futuro - Hito 4)
    // $routes->get('components', 'Admin\Components::index');

    // Gestión de dashboards (futuro - Hito 6)
    // $routes->get('dashboards', 'Admin\Dashboards::index');

    // Gestión de datos (futuro - Hito 3)
    // $routes->get('data', 'Admin\DataManager::index');
});
