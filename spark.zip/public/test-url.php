<?php
/**
 * Test de detección de URL
 * Accede a: http://localhost/wp/dashboard-dinamico-final/test-url.php
 */

echo "<h1>Test de Auto-detección de URL</h1>";
echo "<hr>";

echo "<h2>Variables del servidor:</h2>";
echo "<pre>";
echo "HTTP_HOST: " . ($_SERVER['HTTP_HOST'] ?? 'N/A') . "\n";
echo "SCRIPT_NAME: " . ($_SERVER['SCRIPT_NAME'] ?? 'N/A') . "\n";
echo "REQUEST_URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A') . "\n";
echo "HTTPS: " . ($_SERVER['HTTPS'] ?? 'off') . "\n";
echo "</pre>";

echo "<hr>";

echo "<h2>URL Base calculada:</h2>";
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$scriptDir = dirname($scriptName);
$scriptDir = str_replace('/public', '', $scriptDir);
$scriptDir = rtrim($scriptDir, '/');
$baseURL = $protocol . '://' . $host . $scriptDir . '/';

echo "<pre>";
echo "Protocolo: $protocol\n";
echo "Host: $host\n";
echo "Script Dir: $scriptDir\n";
echo "<strong>BASE URL: $baseURL</strong>\n";
echo "</pre>";

echo "<hr>";
echo "<p><strong>La URL base debería ser:</strong> http://localhost/wp/dashboard-dinamico-final/</p>";
?>
